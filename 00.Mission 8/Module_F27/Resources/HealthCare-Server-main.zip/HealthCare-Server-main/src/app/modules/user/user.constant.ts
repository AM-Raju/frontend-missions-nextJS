export const userSearchableFields: string[] = [
    'email'
];

export const userFilterableFields: string[] = [
    'searchTerm',
    'email',
    'status'
];
