export const scheduleFilterableFields: string[] = ['startDate', 'endDate'];
