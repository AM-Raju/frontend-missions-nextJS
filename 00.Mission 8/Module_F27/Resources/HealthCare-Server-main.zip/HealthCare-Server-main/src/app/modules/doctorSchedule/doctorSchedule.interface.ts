export type IDoctorScheduleFilterRequest = {
  searchTerm?: string | undefined;
  isBooked?: boolean | undefined;
};
