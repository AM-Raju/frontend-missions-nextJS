export interface PaymentInfo {
    amount: number;
    transactionId: string;
    customerName: string;
    customerEmail: string;
}