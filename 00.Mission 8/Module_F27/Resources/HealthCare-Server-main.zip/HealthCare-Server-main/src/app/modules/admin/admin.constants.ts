export const adminSearchableFields: string[] = ['name', 'email', 'contactNo'];

export const adminFilterableFields: string[] = [
  'searchTerm',
  'email',
  'contactNo',
];
