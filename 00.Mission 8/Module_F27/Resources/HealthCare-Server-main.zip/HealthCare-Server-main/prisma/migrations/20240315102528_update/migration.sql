-- AlterTable
ALTER TABLE "admins" ADD COLUMN     "contactNumber" TEXT;
