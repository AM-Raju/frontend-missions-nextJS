-- AlterTable
ALTER TABLE "specialties" ADD COLUMN     "icon" TEXT;
