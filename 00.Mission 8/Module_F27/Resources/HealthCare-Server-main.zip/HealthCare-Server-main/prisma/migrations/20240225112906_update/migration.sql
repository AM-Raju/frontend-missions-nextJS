/*
  Warnings:

  - You are about to drop the column `dateIssued` on the `prescriptions` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "prescriptions" DROP COLUMN "dateIssued";
