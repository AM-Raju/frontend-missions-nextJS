-- AlterTable
ALTER TABLE "patients" ALTER COLUMN "contactNumber" DROP NOT NULL;
