-- DropIndex
DROP INDEX "medicalReports_patientId_key";
