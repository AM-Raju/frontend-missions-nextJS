-- AlterTable
ALTER TABLE "patientHelthDatas" ALTER COLUMN "height" DROP NOT NULL,
ALTER COLUMN "weight" DROP NOT NULL;
