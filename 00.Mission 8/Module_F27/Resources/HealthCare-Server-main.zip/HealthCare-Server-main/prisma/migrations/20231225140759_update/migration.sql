-- AlterTable
ALTER TABLE "patientHelthDatas" ALTER COLUMN "dateOfBirth" DROP NOT NULL,
ALTER COLUMN "mentalHealthHistory" DROP NOT NULL;
